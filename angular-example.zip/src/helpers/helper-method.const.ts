export const HelperMethodsConfig = {
    SEARCH_WORD_CHECKS :  ["id","fund","team"],
}