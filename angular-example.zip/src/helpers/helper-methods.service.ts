import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import { HelperMethodsConfig } from "./helper-method.const";
import { Router } from "@angular/router";

@Injectable()

export class HelperService {


    constructor(private router : Router) {

    }

    checkSearchText(text: string) {
        HelperMethodsConfig.SEARCH_WORD_CHECKS.forEach(x=>{
            if(text.includes(x)){
                console.log(x)
            }
        })
    }

    redirectSearch(text : string){
         this.router.navigate(["/search"], {queryParams : {sqt : text}})
    }
}