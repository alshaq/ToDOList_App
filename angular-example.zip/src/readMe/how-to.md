#Ag-Grid
to implement  ag-grid follow the instructions here https://www.ag-grid.com/ag-grid-angular-angularcli/