import { Component, OnInit } from '@angular/core';

import { FrameworkConfigService } from './../services/framework-config.service';

import { OAuthService } from "angular-oauth2-oidc";
import { OperatorService } from '../../services/util/operator.service';

@Component({
  selector: 'fw-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {

  fcs: FrameworkConfigService;
  userPhoto: string;
  firstName: string;
  fullName : string;

  constructor(private frameworkConfigService: FrameworkConfigService, private oauthService: OAuthService, private operator: OperatorService) {
    this.fcs = frameworkConfigService;
  }

  ngOnInit() {

    if (this.operator.initialized) {
      this.setUserInfo();
    } else {
      this.operator.login.subscribe(x => {
        this.setUserInfo();
      });
    }

  }

  setUserInfo() {
    const claims = this.oauthService.getIdentityClaims();
    this.firstName = claims['given_name'];
    this.userPhoto = claims['picture'];
    this.fullName = claims['name'];
  }

  logout() {
    this.oauthService.logOut();
    window.location.href = "http://myofi/Pages/Home.aspx"
   // console.log("logout");
  }

}
