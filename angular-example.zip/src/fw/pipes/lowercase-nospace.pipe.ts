import { PipeTransform, Pipe } from "@angular/core";

@Pipe({ name: 'lowercaseNospace' })
export class LowercaseNoSpacePipe implements PipeTransform{

    transform(value: string) {
        return value.replace(/\s/g, '').toLowerCase();  
    }

}