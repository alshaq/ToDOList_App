import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { IMenuItem, MenuService } from './../../services/menu.service';
import { Router } from "@angular/router";
import { Observable, Subscription } from "rxjs/Rx";
import { isNullOrUndefined } from "util";

declare var $: any;
@Component({
  selector: 'fw-menu-item',
  templateUrl: './menu-item.component.html',
  styleUrls: ['./menu-item.component.css']
})
export class MenuItemComponent implements OnInit {
  @Input() displaystate: string;
  @Input() item: IMenuItem;
  @Input() disableIcons: boolean = false;
  linksClickedArray: IMenuItem[] = []
  @Input() openLink: string = "";
  @Output() menuLinkOpen: EventEmitter<string> = new EventEmitter<string>();
  ms: MenuService;

  constructor(private menuService: MenuService, private router: Router) {
    this.ms = menuService;

  }

  ngOnInit() {
  }
  parentClicked(menuItem) {
    
    if (this.displaystate === 'open') {
      console.log(this.openLink);
      if (this.openLink != menuItem.text.replace(/\s/g, '').toLowerCase()) {
        if (this.openLink != "") {
          this.toggleSubmenu(this.openLink);
        }
        this.toggleSubmenu(menuItem.text.replace(/\s/g, '').toLowerCase());
        this.menuLinkOpen.emit(menuItem.text.replace(/\s/g, '').toLowerCase());
      } else {
        this.toggleSubmenu(menuItem.text.replace(/\s/g, '').toLowerCase());
        this.menuLinkOpen.emit("");
      }
    } else{
       this.router.navigate([menuItem.route])
    }







    // debugger
    // if (!isNullOrUndefined(this.openLink)) {
    //   this.toggleSubmenu(this.openLink);
    // }
    // this.toggleSubmenu(menuItem.text.replace(/\s/g, '').toLowerCase());
    //this.openLink = menuItem.text.replace(/\s/g, '').toLowerCase();


  }

  // let timer = Observable.timer(2000);
  // timer.subscribe(x => {
  //   debugger
  //   // this.linkTimer()
  // });

  linksClicked(menuItem: IMenuItem) {
   
    if (this.linksClickedArray.length == 0 && menuItem.text != "Search") {
      this.linksClickedArray.push(menuItem);
      this.toggleSubmenu(menuItem.text.toLocaleLowerCase());

    } else {
      var index = 0;
      this.linksClickedArray.forEach(x => {

        if (x.text == menuItem.text) {
          console.log("index", index);
          this.linksClickedArray.splice(index, 1);
          this.router.navigate([menuItem.route])
          return;
        }
        index += 1;

      })
      if (menuItem.text == "Search") {
        
        this.router.navigate([menuItem.route])
      }
    }
    console.log("clicked : ", this.linksClickedArray);
  }

  toggleSubmenu(text) {
    console.log("toggle menu");
    $("li fw-menu-item .sub-menu#" + text).css("color", "blue !important")
    $("li fw-menu-item .sub-menu#" + text).toggleClass("hide");
    $("#" + text + "-plus").toggleClass("hide");
    $("#" + text + "-minus").toggleClass("hide");
    return;
  }

  linkTimer() {
    this.linksClickedArray = [];
    console.log("timer ran");
  }

}
