import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MenuService } from '../../services/menu.service';

@Component({
  selector: 'fw-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  @Input() displaystate: string;
  openLink: string;
  ms: MenuService;
  year: any;
  openSubmenu: boolean = false;
  constructor(private menuService: MenuService) {
    this.ms = menuService;

    var date = new Date();
    this.year = date.getFullYear();
  }

  ngOnInit() {
  }

  setOpenLink(text){    
    this.openLink = text;
  }

}
