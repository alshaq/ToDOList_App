import { Component, Input } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector: 'loading-screen',
    templateUrl: './loading-screen.component.html',
    styleUrls: ['./loading-screen.component.css',
     './loading-screen.component.sass']
})

export class LoadingScreenComponent {
    @Input() message : string = "Loading Results";
    
    constructor(private route: ActivatedRoute) {
        
    }
} 