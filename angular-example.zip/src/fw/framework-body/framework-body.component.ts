import { Component, OnInit } from '@angular/core';
import { ScreenService } from "../services/screen.service";

@Component({
  selector: 'fw-framework-body',
  templateUrl: './framework-body.component.html',
  styleUrls: ['./framework-body.component.css']
})
export class FrameworkBodyComponent implements OnInit {

  menuState = "open";
  ss: ScreenService;
  sidenavWidth = 278;
  constructor(screenService: ScreenService) {
    this.ss = screenService;
  }

  ngOnInit() {
  }

  //toggle the sidenav
  sidenavtoggle() {
    let state: boolean = true;
    console.log(this.menuState);
    if (this.menuState == "open") {
      this.ss.menuExpanded = false;
      this.sidenavWidth = 78;
      this.menuState = "closed";
      state = false;
    } else {
      this.ss.menuExpanded = true;
      this.sidenavWidth = 278;
      this.menuState = "open";
      state = true;
    }
    // this.ss.onmenuExpandAction.emit(state);
    console.log("changed to: ", this.menuState);
  }

}
