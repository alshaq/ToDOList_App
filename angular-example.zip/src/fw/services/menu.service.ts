import { Injectable } from '@angular/core';

export interface IMenuItem {
    text: string,
    icon: string,
    route: string,
    submenu: Array<IMenuItem>,
    submenuIcon : string
}

@Injectable()
export class MenuService {

    items: Array<IMenuItem>;

    isVertical = true;

    showingLeftSideMenu = false;

    toggleLeftSideMenu(): void {
        this.isVertical = true;
        this.showingLeftSideMenu = !this.showingLeftSideMenu;

    }

    toggleMenuOrientation(): void {
        this.isVertical = !this.isVertical;
    }
}