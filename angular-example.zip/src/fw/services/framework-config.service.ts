import { Injectable } from '@angular/core';
import { IIconFiles } from './../models/IIconFiles';
import { IFrameworkConfigSettings } from './../models/IFrameworkConfigSettings';

@Injectable()
export class FrameworkConfigService {

  showLanguageSelector = true;
  showUserControls = true;
  showStatusBar = true;
  showStatusBarBreakpoint = 0;
  socialIcons = new Array<IIconFiles>();

  configure(settings: IFrameworkConfigSettings) : void {
    Object.assign(this, settings);
  }

}
