import { HostListener, Injectable, EventEmitter } from "@angular/core";
import { Subject } from "rxjs/Subject";

@Injectable()
export class ScreenService {
  private resizeSource = new Subject<null>();
  resize$ = this.resizeSource.asObservable();

  largeBreakpoint = 800;
  screenWidth = 1000;
  screenHeight = 800;

  //   onmenuExpandAction: EventEmitter<boolean>;
  menuExpanded : boolean = true;

  constructor() {
    // this.onmenuExpandAction = new EventEmitter();
    try {
      this.screenWidth = window.innerWidth;
      this.screenHeight = window.innerHeight;
      window.addEventListener("resize", event => this.onResize(event));
    } catch (e) {
      //go to default screen dimensions (lines 10/11)
    }
  }

  isLarge(): boolean {
    return this.screenWidth >= this.largeBreakpoint;
  }

  onResize($event): void {
    this.screenWidth = window.innerWidth;
    this.screenHeight = window.innerHeight;
    console.log("here: ", this.screenWidth, this.screenHeight);
    this.resizeSource.next();
  }

  isMenuExpanded(): boolean {
    return this.menuExpanded;
  }
}
