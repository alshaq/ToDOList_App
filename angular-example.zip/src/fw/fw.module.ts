import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FrameworkBodyComponent } from './framework-body/framework-body.component';
import { ContentComponent } from './content/content.component';
import { TitleBarComponent } from './title-bar/title-bar.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { StatusBarComponent } from './status-bar/status-bar.component';
import { Title } from '@angular/platform-browser';
import { FrameworkConfigService } from './services/framework-config.service';
import { ScreenService } from './services/screen.service';
import { MenuService } from './services/menu.service';
//import { MatButtonModule, MatButtonToggleModule, MatMenuModule } from "@angular/material";

import { ScreenLarge } from './directives/screen-large.directive';
import { ScreenBelowLarge } from './directives/screen-below-large.directive';
import { MenuComponent } from './menus/menu/menu.component';
import { MenuItemComponent } from './menus/menu-item/menu-item.component';
import { RouterModule } from '@angular/router';
import { CustomMaterialModule } from "../app/material.module";
import { MiniNavStyler } from "./directives/mini-nav-styler.directive";
import { LoadingScreenComponent } from "./loading-screen/loading-screen.component";
import { LowercaseNoSpacePipe } from "./pipes/lowercase-nospace.pipe";

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    CustomMaterialModule
  ],
  declarations: [
    FrameworkBodyComponent,
    ContentComponent,
    MenuComponent,
    MenuItemComponent,
    TitleBarComponent,
    TopBarComponent,
    StatusBarComponent,
    ScreenLarge,
    MiniNavStyler,
    LowercaseNoSpacePipe 
  ],
  providers: [
    FrameworkConfigService,
    MenuService,
    ScreenService,

  ],
  exports: [
    FrameworkBodyComponent,
    CustomMaterialModule
  ]
})
export class FwModule { }
