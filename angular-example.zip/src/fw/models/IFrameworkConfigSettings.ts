import { IIconFiles } from './IIconFiles';

export interface IFrameworkConfigSettings{
    showLanguageSelector?: boolean,
    showUserControls?: boolean,
    showStatusBar?: boolean,
    showStatusBarBreakpoint?: number,
    socialIcons?: Array<IIconFiles>
}