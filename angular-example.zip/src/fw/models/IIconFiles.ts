export interface IIconFiles{
    imageFile: string,
    alt: string,
    link: string
}