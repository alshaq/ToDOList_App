import {
  Directive,
  ElementRef,
  Input,
  Renderer2,
  OnDestroy,
  TemplateRef,
  ViewContainerRef
} from "@angular/core";

import { ScreenService } from "../services/screen.service";
import { Subscription } from "rxjs/Subscription";

@Directive({ selector: "[miniNavStyler]" })
export class MiniNavStyler implements OnDestroy {
  private screenSubscription: Subscription;

  offsetExpanded = 274;
  offsetCollapsed = 200;
  activeOffset = this.offsetExpanded;

  constructor(
    private viewContainer: ViewContainerRef,
    private template: TemplateRef<Object>,
    private screenService: ScreenService,
    private renderer: Renderer2,
    private hostElement: ElementRef
  ) {
    this.viewContainer.createEmbeddedView(this.template);
    this.screenSubscription = screenService.resize$.subscribe(() =>
      this.onResize()
    );
  }

  @Input()
  set miniNavStyler(condition) {}

  ngOnDestroy() {
    this.screenSubscription.unsubscribe();
  }

  onResize() {
    if (this.screenService.menuExpanded) {
      this.activeOffset = this.offsetExpanded;
      // this.renderer.removeClass(this.hostElement.nativeElement, 'minicollapsed');
      // this.renderer.addClass(this.hostElement.nativeElement, 'miniexpanded');
    } else if (!this.screenService.menuExpanded) {
      this.activeOffset = this.offsetCollapsed;
      // this.renderer.removeClass(this.hostElement.nativeElement, 'miniexpanded');
      // this.renderer.addClass(this.hostElement.nativeElement, 'minicollapsed');
    }
    let newWidth = this.screenService.screenWidth - this.activeOffset;
    this.renderer.removeAttribute(
      this.hostElement.nativeElement.nextElementSibling,
      "style"
    );
    this.renderer.setAttribute(
      this.hostElement.nativeElement.nextElementSibling,
      "style",
      "width=" + newWidth.toString() + "px"
    );
    console.log("styler:", newWidth);
    // this.miniNavStyler = true;
  }
}
