
import { NgModule } from '@angular/core';
import { AppComponent } from "../../app.component";
import { ServiceErrorComponent, ServiceErrorDialog } from "./service-error/service-error.component";




@NgModule({
  declarations: [
     ServiceErrorDialog,
    
  ],
  imports: [
    
  ],
  providers: [ServiceErrorComponent],
  bootstrap: [AppComponent],
   entryComponents: [ ServiceErrorDialog] ,
})
export class ErrorModule { }
