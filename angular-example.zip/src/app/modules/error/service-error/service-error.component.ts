
import { OnInit, Component, Inject } from "@angular/core";
import { isNullOrUndefined } from "util";
import { ErrorVariables } from "../../../models/error-variables";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { OAuthService } from "angular-oauth2-oidc";
import { AppComponent } from "../../../app.component";
import { environment } from "../../../../environments/environment";
import { JwksValidationHandler } from "angular-oauth2-oidc";
import { OperatorService } from "../../../../services/util/operator.service";
declare var $: any;

@Component({
    selector: 'service-error',
    templateUrl: './service-error.component.html',
    styleUrls: ['./service-error.component.css']
})

export class ServiceErrorComponent implements OnInit {
    errorVariables: ErrorVariables;
    test_error: any = "hh"
    /**
     *
     */
    constructor(public dialog: MatDialog, private oauthService: OAuthService) {
        this.errorVariables = new ErrorVariables();
    }
    serviceErrors(err?) {
        
        if (!isNullOrUndefined(err)) {
            // console.log(err);
            var result = this.checkErrorForInvalidToken(err);
            if (!result)
                var errorObject = this.parseError(err);

        }
        if (!result) {
            let dialogRef = this.dialog.open(ServiceErrorDialog, {
                width: '50%',
                data: { status: errorObject.status, message: errorObject.description },

            });

            dialogRef.afterClosed().subscribe(result => {
                // console.log('The dialog was closed');
                // this.animal = result;
            });

        }

    }

    parseError(err): ErrorVariables {
       
        var _err = new ErrorVariables();
        try {
            _err.description = (!isNullOrUndefined(err.message)) ? err.message : " Unexpected Error Occur";
            _err.status = (!isNullOrUndefined(err.status)) ? err.status : "Unknown Status Code";

            // console.log(_err);
        } catch (e) {

        }
        return _err;
    }

    ngOnInit(): void {
    }


    checkErrorForInvalidToken(err): boolean {
        var _error = (!isNullOrUndefined(err.error)) ? err.error : null;

        if (!isNullOrUndefined(err.error)) {
            if (err.error.error == "invalid_token") {
              
                this.authorizeUser();
                return true;
            }
        }
    }


    authorizeUser() {

        
        this.oauthService.redirectUri = environment.forgerock_config.redirect_uri;
        this.oauthService.clientId = environment.forgerock_config.client_id;
        this.oauthService.scope = environment.forgerock_config.scope;
        this.oauthService.issuer = environment.forgerock_config.issuer;
        this.oauthService.tokenValidationHandler = new JwksValidationHandler();
        this.oauthService.requireHttps = false;


        this.oauthService.strictDiscoveryDocumentValidation = false;

        this.oauthService.loadDiscoveryDocumentAndLogin().then(() => {
            
            if(this.oauthService.getAccessToken()){
                console.log("service error");
            };
        }); 




    }
}



@Component({
    selector: 'dialog-error',
    templateUrl: './service-error-dialog.component.html',
    styleUrls: ['./service-error.component.css']
})
export class ServiceErrorDialog {

    constructor(
        public dialogRef: MatDialogRef<ServiceErrorDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}