/**
 *  Using async calls throughout the application , use an eventemitter to notify 
 * the method you want to call after another it is time to run - this is 
 * incase their some relation between the different methods
 */
import { OnInit, Component, Inject } from "@angular/core";
import { HttpParams, HttpHeaders } from "@angular/common/http";
import { OperatorService } from "../../../services/util/operator.service";
import { Global } from "../../global/global.const";
import { OfiHttp } from "../../models/OfiHttp";
import { HttpBasicAuthService } from "../../../services/util/httpExtensions/httpBasicAuth.service";
import { HttpSSOService } from "../../../services/util/httpExtensions/httpSSO.service";
import { SampleData } from "../../models/SampleData";
import { FormControl, FormGroup, FormBuilder } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { startWith, map } from "rxjs/operators";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { isNullOrUndefined } from "util";
import { Router } from "@angular/router";
declare var $: any;

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {


    public static advancedSearchFilters: string[] = []
    advancedSearchLength: number = HomeComponent.advancedSearchFilters.length;
    requestParams: OfiHttp;
    searchFliterCtrl: FormControl;
    searchText: string;
    filteredResults: Observable<any[]>;
    dropdownExamples: any[] = ["Value and Income Equity Team", "Dividend Value", "Large Cap Core",
        "Main Street Equity Team", "Small and Mid Cap Growth Equity Team", "Oppenheimer Discovery Mid Cap Growth Fund"];
    

    constructor(private _httpBasicAuth: HttpBasicAuthService, private _httpSSO: HttpSSOService,
        private operator: OperatorService, public dialog: MatDialog, private router : Router) {
        this.searchFliterCtrl = new FormControl();
        this.filteredResults = this.searchFliterCtrl.valueChanges.pipe(
            startWith(''), map(x => x.length >= 1 ? this.filterAllResults(x) : null)
        );

        this.searchFliterCtrl.valueChanges.subscribe(x => {
            this.searchText = x;

            console.log(this.searchText);
        });
    }
    ngOnInit(): void {
        if (this.operator.initialized) {

        } else {
            this.operator.login.subscribe(x => {

            });
        }
    }

    filterAllResults(name: string) {

        // console.log("index", this.dropdownExamples.filter(x =>
        //     x.toLowerCase().charAt(
        //         x.toLowerCase().indexOf(name.toLowerCase()))))
        // return this.dropdownExamples.filter(x =>
        //   x.toLowerCase().indexOf(name.toLowerCase()) === 0);
        return this.dropdownExamples.filter(x =>
            x.toLowerCase().charAt(
                x.toLowerCase().indexOf(name.toLowerCase())))
    }


    advancedSearch() {

        let dialogRef = this.dialog.open(AdvancedSearchComponent, {
            id: "advanced-search-modal",
            width: '60%',
            data: {},
            disableClose: true,
            position: {
                top: "50px",
            }

        });


        dialogRef.afterClosed().subscribe(result => {
            if (result) {

                this.advancedSearchLength = result.length;
                HomeComponent.advancedSearchFilters = result;
                console.log("Home: ", HomeComponent.advancedSearchFilters);
            }
        });
    }

    search() {
        if (!isNullOrUndefined(this.searchText) && this.searchText != "") {
            //CODE FOR RESULTS PAGE GOES HERE
            this.router.navigate(["/search"], {queryParams : {sqt : this.searchText}})
            console.log("search please")

            return
        }
        console.log("no text to search")
        console.log(this.searchText)
    }

}

@Component({
    selector: 'mdl-advanced-search',
    templateUrl: './advanced-search.component.html',
    styleUrls: ['./advanced-search.component.css']
})

export class AdvancedSearchComponent {
    resetFilter: boolean = true;
    teamsFormGroup: FormGroup;
    selectedFilters: string[] = [];
    unselectedFilters: string[] = [];

    teams: any
    columnValue: boolean = true;
    rowValue: boolean = true;
    thirdRow: boolean = false;
    secondRow: boolean = false;
    firstRow: boolean = false;
    investmentTeams: string[] =
    [
        " Alternative Strategies",
        " Beta Solutions",
        " Cash Strategies",
        " Emerging Markets Equity",
        " Global Debt",
        "Global Equity",
        "Global Infastructure Securities",
        "Global Multi- Asset Group",
        "Investment Grade Debt",
        "Main Street Equity ",
        "Multi- Sector Fixed Income",
        "Real Estate",
        "Rochester Municipals",
        "Senior Corporate Loan",
        "Small and Mid Cap Growth Equity ",
        "SteelPath",
        "Test Strategy Investment",
        "Thematic Equities ",
        "Value and Income Equity ",
    ]
    constructor(private formBuilder: FormBuilder,
        public dialogRef: MatDialogRef<AdvancedSearchComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.dialogRef.afterClosed().subscribe(x => {

        })
    }

    ngOnInit() {
        //his.selectedFilters = HomeComponent.advancedSearchFilters;
        this.teamsFormGroup = this.formBuilder.group({
            teams: this.formBuilder.array([])
        });
    }

    setRow(index) {
        
        var calRow = Math.floor(this.investmentTeams.length / 2);
        var calColumn = index % 2

        if (calColumn == 1) {
            this.columnValue = false;
            this.rowValue = false;
            // this.rowValue = false; 
        } else {
            this.columnValue = true;

        }

        console.log("row index", (index % 2));

        console.log("First row : ", this.firstRow);
        console.log("Second row : ", this.secondRow);
        console.log("third row : ", this.thirdRow);

        return true;
    }

    filterSelected(event) {
        this.resetFilter = true;
        //HomeComponent.advancedSearchFilters.push(event.source.value);
        if (event.checked) {
           this.selectedFilters.push(event.source.value)
            HomeComponent.advancedSearchFilters.push(event.source.value)
        } else {
            // this.selectedFilters.splice(this.selectedFilters.indexOf(event.source.value), 1)
            this.unselectedFilters.push(event.source.value)
            HomeComponent.advancedSearchFilters.splice(HomeComponent.advancedSearchFilters.indexOf(event.source.value), 1)
        }

        console.log("Filters : ", this.selectedFilters);
    }

    checkSelected(filter) {
        this.resetFilter = true;
        if (HomeComponent.advancedSearchFilters.indexOf(filter) == -1) {
            return false;
        }
        return true;
    }

    applyFilters() {

        this.dialogRef.close(HomeComponent.advancedSearchFilters);
    }

    cancel() {
      
        if (this.unselectedFilters.length != 0) {
            this.unselectedFilters.forEach(x=>{
                HomeComponent.advancedSearchFilters.push(x)
            })
            
        }

        if(this.selectedFilters.length !=0){     
            
            this.selectedFilters.forEach( x=>{
                  HomeComponent.advancedSearchFilters.splice(HomeComponent.advancedSearchFilters.indexOf(x), 1)
            });
        }
        this.dialogRef.close(HomeComponent.advancedSearchFilters);

    }

    resetFilters() {
        HomeComponent.advancedSearchFilters = [];
        this.selectedFilters = [];      
    }
} 