import { Component, Input } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
selector: 'app-single-result',
  templateUrl: './single-result.component.html',
  styleUrls: ['./single-result.component.css']
})

export class SingleResultComponent {

   @Input() loading : boolean;
 
  constructor() {
    // console.log(this.route.snapshot['_routerState'].url);
    //   this.route.parent.params.subscribe(params => console.log(params));
  }
} 