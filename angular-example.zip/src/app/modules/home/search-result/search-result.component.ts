import { Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs/Rx";
import { startWith, map } from "rxjs/operators";
import { isNullOrUndefined } from "util";
import { HelperService } from "../../../../helpers/helper-methods.service";
import { RepositoryService } from "../../../../services/repositories/repository.service";
import { HttpSSOService } from "../../../../services/util/httpExtensions/httpSSO.service";
import { Global } from "../../../global/global.const";
import { HttpHeaders } from "@angular/common/http";


@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})

export class SearchResultsComponent {
  loading: boolean = false;
  searchFliterCtrl: FormControl;
  filteredResults: Observable<any[]>;
  searchText: string = "Equity";
  times: number = 5;
  investmentTeams: string[] =
  [
    " Alternative Strategies",
    " Beta Solutions",
    " Cash Strategies",
    " Emerging Markets Equity",
    " Global Debt",
    "Global Equity",
    "Global Infastructure Securities",
    "Global Multi- Asset Group",
    "Investment Grade Debt",
    "Main Street Equity ",
    "Multi- Sector Fixed Income",
    "Real Estate",
    "Rochester Municipals",
    "Senior Corporate Loan",
    "Small and Mid Cap Growth Equity ",
    "SteelPath",
    "Test Strategy Investment",
    "Thematic Equities ",
    "Value and Income Equity ",
  ]
  dropdownExamples: any[] = ["Value and Income Equity Team", "Dividend Value", "Large Cap Core",
    "Main Street Equity Team", "Small and Mid Cap Growth Equity Team", "Oppenheimer Discovery Mid Cap Growth Fund",
    " Alternative Strategies",
    " Beta Solutions",
    " Cash Strategies",
    " Emerging Markets Equity",
    " Global Debt",
    "Global Equity",
    "Global Infastructure Securities",
    "Global Multi- Asset Group",
    "Investment Grade Debt",
    "Main Street Equity ",
    "Multi- Sector Fixed Income",
    "Real Estate",
    "Rochester Municipals",
    "Senior Corporate Loan",
    "Small and Mid Cap Growth Equity ",
    "SteelPath",
    "Test Strategy Investment",
    "Thematic Equities ",
    "Value and Income Equity "]


  constructor(private _route: ActivatedRoute, private _router: Router,
    private _helper: HelperService, private _repo: RepositoryService, private _httpSSO: HttpSSOService) {
    this.runUrlCheck();
    this.searchFliterCtrl = new FormControl();
    this.filteredResults = this.searchFliterCtrl.valueChanges.pipe(
      startWith(''), map(x => x.length >= 1 ? this.filterAllResults(x) : null)
    );

    this.searchFliterCtrl.valueChanges.subscribe(x => {
      this.searchText = x;
    });

  }

  filterAllResults(name: string) {
    return this.dropdownExamples.filter(x =>
      x.toLowerCase().charAt(
        x.toLowerCase().indexOf(name.toLowerCase())))
  }


  searchEntered() {

    this._router.navigate(["/search"], { queryParams: { sqt: this.searchText } });
    this.queryForData(this.searchText);
  }

  runUrlCheck() {
    // console.log(this.route.snapshot.queryParams["sqt"]);
    // this.route.parent.params.subscribe(params => console.log(params));
    this.searchText = this._route.snapshot.queryParams["sqt"];

    if (isNullOrUndefined(this.searchText)) {
      this._router.navigate([""]);
    }
    else {

      if (this.searchText == "") {
        this._router.navigate([""]);
      } else {
        this.queryForData()
      }

    }

  }

  queryForData(text?: string) {
    let session = sessionStorage;
    console.log(session);
    console.log("search");
    var subcription = this._repo.getMockData().subscribe(x => {
      console.log(x);
      subcription.unsubscribe();
    });
 
  }

 


} 