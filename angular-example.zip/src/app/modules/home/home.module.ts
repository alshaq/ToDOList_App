


import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { AppComponent } from "../../app.component";
import { AdvancedSearchComponent } from "./home.component";
import { CustomMaterialModule } from "../../material.module";
import { ReactiveFormsModule } from "@angular/forms";
import { SingleResultComponent } from "./search-result/single-result.component";
import { SearchResultsComponent } from "./search-result/search-result.component";
import { LoadingScreenComponent } from "../../../fw/loading-screen/loading-screen.component";
import { HelperService } from "../../../helpers/helper-methods.service";

@NgModule({
    declarations: [
        AdvancedSearchComponent ,
        SingleResultComponent,
        SearchResultsComponent,
         LoadingScreenComponent 
    ],
    imports: [CustomMaterialModule, CommonModule,  ReactiveFormsModule,],
    providers: [HelperService],
    exports: [ 

        CustomMaterialModule,
 
    ],
    bootstrap: [AppComponent],
     entryComponents: [ AdvancedSearchComponent] ,
})

export class HomeModule{
    
}