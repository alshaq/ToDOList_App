import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { HeaderComponent } from "./header/header.component";

import { AppComponent } from "../../app.component";
import { FooterComponent } from "./footer/footer.component";
import { CustomMaterialModule } from "../../material.module";




@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent
  ],
  imports: [RouterModule, CustomMaterialModule, CommonModule],
  providers: [],
  exports: [
    HeaderComponent,
    CustomMaterialModule,
    FooterComponent 
  ],
  bootstrap: [AppComponent]
})
export class SharedModule { }
