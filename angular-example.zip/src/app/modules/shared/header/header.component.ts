import { Component, OnInit } from "@angular/core";
import { OAuthService } from "angular-oauth2-oidc";
import { OperatorService } from "../../../../services/util/operator.service";

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
    
})

export class HeaderComponent implements OnInit {
    user_photo: string;
    user_name: string;

    navLinks = [
        {label : 'Home', link: 'home'},
        {label : 'Table', link: 'table'},
        {label : 'Graph', link: 'graph'},
        {label : 'APIs', link: 'api'}
    ];

    
    ngOnInit(): void {

        if (this.operator.initialized) {
            this.setUserInfo();
        } else {
            this.operator.login.subscribe(x => {
                this.setUserInfo();
            });
        }

    }
    /**
     *
     */
    constructor(private oauthService: OAuthService, private operator: OperatorService) {
        
    }

    setUserInfo() {
        const claims = this.oauthService.getIdentityClaims();
        this.user_name = claims['given_name'];
        this.user_photo = claims['picture'];
    }

    logout(){
        this.oauthService.logOut();
       // console.log("logout");
    }
}