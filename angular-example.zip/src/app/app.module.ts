import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
// import { AppRoutingModule } from "./app.routing.module";
import { HomeComponent } from "./modules/home/home.component";
import { HttpClientModule } from "@angular/common/http";
import { ErrorModule } from "./modules/error/error.module";
import { ServiceErrorComponent } from "./modules/error/service-error/service-error.component";

import { AccessDeniedComponent } from "./modules/access-denied/access-denied.component";
import { NotFoundComponent } from "./modules/not-found/not-found.component";
import { AuthComponent } from "./modules/auth/auth.component";
import { OAuthService } from "angular-oauth2-oidc";
import { UrlHelperService } from "angular-oauth2-oidc";

import { HeaderComponent } from "./modules/shared/header/header.component";
import { HttpExtensions } from "../services/util/httpExtensions/httpExtensions.module";
import { EmployeeService } from "../services/util/employee.service";
import { OperatorService } from "../services/util/operator.service";
import { UserService } from "../services/util/user.service";
import { AuthGuardService } from "../services/util/auth-guard.service";
import { MatProgressBarModule, MatAutocompleteModule, MatButtonModule, MatButtonToggleModule, MatCardModule, MatChipsModule, MatDatepickerModule, MatCheckboxModule, MatStepperModule, MatDialogModule, MatTooltipModule, MatToolbarModule, MatTabsModule, MatTableModule, MatSortModule, MatSnackBarModule, MatSlideToggleModule, MatSliderModule, MatSidenavModule, MatSelectModule, MatRippleModule, MatRadioModule, MatProgressSpinnerModule, MatPaginatorModule, MatNativeDateModule, MatMenuModule, MatListModule, MatIconModule, MatExpansionModule, MatDividerModule, MatGridListModule, MatInputModule } from "@angular/material";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { SharedModule } from "./modules/shared/shared.module";
import { FwModule } from './../fw/fw.module';
import { appRoutes } from './app.routing';
import { GridComponent } from "./modules/table-grid/grid.component";
import { AgGridModule } from "ag-grid-angular";
import { RedComponentComponent } from "./components/red-component.component";
import { AppRoutingModule } from "./app.routing.module";
import { ProfileComponent } from "./modules/profile/profile.component";
import { CustomMaterialModule } from "./material.module";
import { ModalsModule } from "./modals/modals.module";
import { HomeModule } from "./modules/home/home.module";
import { EquityModule } from "./modules/equity/equity.module";
import { RepositoryService } from "../services/repositories/repository.service";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ServiceErrorComponent,
    AccessDeniedComponent,
    NotFoundComponent,
    AuthComponent,
    GridComponent,
    RedComponentComponent,
    ProfileComponent,
    

    // HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    // AppRoutingModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    ReactiveFormsModule,

    CommonModule,
    FwModule,
    HttpClientModule,
    HttpExtensions,
    ErrorModule,
    SharedModule,
    CustomMaterialModule,
    BrowserAnimationsModule,
    AgGridModule.withComponents([
      RedComponentComponent
    ]),
    HomeModule,
    EquityModule

  ],
  exports: [

    CustomMaterialModule
  ],
  providers: [OperatorService, UserService, EmployeeService, AuthGuardService, OAuthService, UrlHelperService,RepositoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
