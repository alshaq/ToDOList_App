import { HttpHeaders, HttpParams, HttpClient } from "@angular/common/http";

export class OfiHttp {
    body?: string;
    url? : string; 
    params?: HttpParams;
    headers? :  HttpHeaders;
    session? : any;

}

