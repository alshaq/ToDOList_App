export const MethodType = {
    GET : "get",
    POST : "post",
    PUT : "put",
    PATCH : "patch",
    DELETE : "delete",
    HEAD : "head"
}