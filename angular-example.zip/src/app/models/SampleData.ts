export class SampleData {
    static homeScreenArticles: any[] = [
        {
            title: 'Authorization',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " +
            "Curabitur mollis, mi nec vestibulum vehicula, lectus eros vestibulum urna,"+
            "quis sollicitudin libero diam sed velit. Proin quis ipsum in sem mollis aliquet."+
            "Pellentesque vulputate eleifend velit ac congue. Nullam viverra, libero vit"+
             "Class aptent taciti sociosqu ad litora torquent per conubia nostra, "+
             "per inceptos himenaeos. Phasellus suscipit ante vitae augue placerat"+ 
             "ac ornare nunc pretium. "+
            "Aliquam lobortis pharetra nulla vitae lacinia. "+
            "Nulla ut nisl tortor. Quisque molestie ut dui non consequat."
           
        },
         {
            title: 'Examples',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " +
            "Curabitur mollis, mi nec vestibulum vehicula, lectus eros vestibulum urna,"+
            "quis sollicitudin libero diam sed velit. Proin quis ipsum in sem mollis aliquet."+
            "Pellentesque vulputate eleifend velit ac congue. Nullam viverra, libero vit"+
             "Class aptent taciti sociosqu ad litora torquent per conubia nostra, "+
             "per inceptos himenaeos. Phasellus suscipit ante vitae augue placerat"+ 
             "ac ornare nunc pretium. "+
            "Aliquam lobortis pharetra nulla vitae lacinia. "+
            "Nulla ut nisl tortor. Quisque molestie ut dui non consequat."
           
        },
         {
            title: 'ForgeRock',
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " +
            "Curabitur mollis, mi nec vestibulum vehicula, lectus eros vestibulum urna,"+
            "quis sollicitudin libero diam sed velit. Proin quis ipsum in sem mollis aliquet."+
            "Pellentesque vulputate eleifend velit ac congue. Nullam viverra, libero vit"+
             "Class aptent taciti sociosqu ad litora torquent per conubia nostra, "+
             "per inceptos himenaeos. Phasellus suscipit ante vitae augue placerat"+ 
             "ac ornare nunc pretium. "+
            "Aliquam lobortis pharetra nulla vitae lacinia. "+
            "Nulla ut nisl tortor. Quisque molestie ut dui non consequat."
           
        },
    ]
}