import { Response } from "@angular/http";

export const ErrorConstant = {
    POPUP: {
        TOP: "small",
        BOTTOM: "big",
        CENTER: "center"
    },
    DEFAULT_MESSAGE: {
        LEVEL_1: "APP Is Still Functional, However Your Information Wasn't Loaded Properly.",
        LEVEL_2: "APP Crashed Reload Please",
        LEVEL_3: {
            MESSAGE: "Contact Support",
            LINK: "mailto:ML-MQHelp@OFI.com?subject=Plexus Question&body=Hello AMQ Team,%0A%0aI have the following questions about the AMQ platform.%0A%0aThanks!",
        },
        SERVICE_ERROR_TIMEOUT_MESSAGE : "Looks like the server is taking too long to respond, this can be caused by either poor connectivity or an error with our servers."
        
    },
    SERVICE_TIMEOUT : 60000,
    SERVICE_DELAY : 10000,
    COLOR: { 
        WARNING: "#ffa000",
        ERROR: "#c62828"
    },
    ICON: {
        WARNING: "fa fa-exclamation-triangle",
        ERROR: "fa fa-exclamation-circle"
    },
    TITLE:{
        WARNING : "Warning",
        ERROR : "Error",
    }
};

export class ErrorVariables {
    error: Response;
    description : string;
    status : string;
    redirect: boolean;
    popupOptions: any;
    specific_info: string;
    link: string;
    color: any;
    icon: any;
    title: any;
    /**
     * Returns a constant that would place the error message on the top.
     * @returns {string}
     */
    getTop() {
        return ErrorConstant.POPUP.TOP;
    }

    /**
    * Returns a constant that would place the error message on the bottom.
    * @returns {string}
    */
    getBottom() {
        return ErrorConstant.POPUP.BOTTOM;
    }

    /**
    * Returns a constant that would place the error message in the center.
    * @returns {string}
    */
    getCenter() {
        return ErrorConstant.POPUP.CENTER;
    }

    /**
     * Returns a level one message that is more like a warning that something went wrong but the application is still functional.
     * @returns {string} 
     */
    getLvl1DefaultMsg() {
        return ErrorConstant.DEFAULT_MESSAGE.LEVEL_1;
    }

    /**
     * Returns a level two message that inform the user that they should refresh the page.
     * @returns {string} 
     */
    getLvl2DefaultMsg() {
        return ErrorConstant.DEFAULT_MESSAGE.LEVEL_2;
    }

    /**
     * Returns a level three message that should be used incase of a possible fatality of the application if an error occurred by another function. 
     * Used alongside the getLvl3DefaultLink() function which includes the Contact Link to reference where the user should go.
     * @returns {string} 
     */
    getLvl3DefaultMsg() {
        return ErrorConstant.DEFAULT_MESSAGE.LEVEL_3.MESSAGE;
    }
    /**
     * Returns the link the user should use to contact the support team for the application
     * @returns {string}
     */
    getLvl3DefaultLink() {
        return ErrorConstant.DEFAULT_MESSAGE.LEVEL_3.LINK;
    }
    /**
     * Returns the code for the color warning
     * @returns {string}
     */

    getWarningColor() {
        return ErrorConstant.COLOR.WARNING
    }

    /**
     * Returns the code for the color error
     * @returns {string}
     */
    getErrorColor() {
        return ErrorConstant.COLOR.ERROR
    }

    /**
    * Returns the code for the  icon for warning
    * @returns {string}
    */
    getWarningIcon() {
        return ErrorConstant.ICON.WARNING
    }


     /**
     * Returns the code for the icon for  error
     * @returns {string}
     */
    getErrorIcon() {
        return ErrorConstant.ICON.WARNING
    }

    getErrorTitle() {
        return ErrorConstant.TITLE.ERROR
    }

    getWarningTitle() {
        return ErrorConstant.TITLE.WARNING
    }


}