

import { IPositionStatus } from "../models/position.status.model";

export const GlobalUtils = {

    expired(currentStamp: number, stampSpan: number){
        let currentTime: number = Date.now();
        return (currentTime > (currentStamp+stampSpan));
    },

    getStatusName(status: IPositionStatus): string{
        let result: string;
        result = status.status_name;
        if (status.substatus_name){
            result += ' ' + status.substatus_name;
        }
        return result;

    }

}