export interface OpenIDConfiguration {
  authorization_endpoint: string;
  userinfo_endpoint: string;
  end_session_endpoint: string;
}