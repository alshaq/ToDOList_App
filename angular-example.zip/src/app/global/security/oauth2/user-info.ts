// interface IUserInfo {
//   sub: string;
//   address: {
//     formatted: string
//   };
//   name: string;
//   phone_number: string;
//   given_name: string;
//   family_name: string;
//   email: string;
// }

//TODO tightly coupled with fw component.  Should it be?
import { environment } from './../../../../environments/environment';
import './../../global.const';
import { IOFIEmployee } from "../../../models/ofiemployee.model";


export class UserInfo  {
  constructor(){  }

  sub: string;
  roles: [string];
  employee_details: IOFIEmployee;
}

