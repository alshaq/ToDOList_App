//https://medium.com/@amcdnl/global-error-handling-with-angular2-6b992bdfb59c

import { ErrorHandler, Injector, Injectable } from '@angular/core';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';

// import * as StackTrace from 'stacktrace-js';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(private injector: Injector){ }

    handleError(error){

        const location = this.injector.get(LocationStrategy);
        const message = error.message ? error.message : error.toString();

        const url = location instanceof PathLocationStrategy ? location.path() : '';

        // StackTrace.fromError(error).then(stackframes => {
        //     //console.log('parsed stack trace', stackframes);
        //     //dump the first 20 stack frames and deal with just our app code
        //     const stackString = stackframes.splice(0,20).map(function(sf){ return sf.toString();}).join('\n');            
        //     //const stackString = 'stackframes failures';
        //     console.log('log this error to log service!', message);
        //     console.log('url: ', url);
        //     console.log('stack trace: ', stackString);

        // });

//          uncomment below line if we want to bubble the error up and not have it swallowed here!
//          throw error;
    }

}