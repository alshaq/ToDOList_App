export const Global = {
    SESSION: {
        STATE_STORAGE_KEY: 'oauth2state',
        SESSION_STORAGE_KEY: 'oauth2session',
        ROUTE_STORAGE_KEY: 'oauth2path',
        ACCESS_TOKEN: 'access_token',
        ID_TOKEN: 'id_token',
        TOKEN_TYPE: 'token_type',
    },
    POSITION: {
        STATUS: {
            VACANT: 1,
            CLOSED: 9
        },
        NAME: {
            VACANT: 'Vacant - Not Recruiting',
            CLOSED: 'Closed'
        }
    }
};

// declare global {
//     interface String {
//         format(s: string[]): string;
//     }


// }