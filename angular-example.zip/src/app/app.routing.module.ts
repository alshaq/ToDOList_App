
//http://blog.angular-university.io/angular2-router/

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { environment } from './../environments/environment';
import { HomeComponent } from "./modules/home/home.component";
import { AuthGuardService } from "../services/util/auth-guard.service";
import { AuthComponent } from "./modules/auth/auth.component";
import { AccessDeniedComponent } from "./modules/access-denied/access-denied.component";
import { NotFoundComponent } from "./modules/not-found/not-found.component";
import { GridComponent } from "./modules/table-grid/grid.component";
import { ProfileComponent } from "./modules/profile/profile.component";
import { EquityComponent } from "./modules/equity/equity.component";
import { SearchResultsComponent } from "./modules/home/search-result/search-result.component";

const routes: Routes = [

  {
    path: '',
    children: [
      // { path: '', redirectTo: '', pathMatch: 'full' }, 
      { path: '', component: HomeComponent },
      { path: 'search', component: SearchResultsComponent},    
      { path: 'table', component: GridComponent },
      { path: 'graph', component: HomeComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'equity', component: EquityComponent },
      { path: 'equity/:id', component: EquityComponent },
      { path: 'alternative', component: EquityComponent },
      { path: 'alternative/:id', component: EquityComponent },
      { path: 'equity-smart-beta', component: EquityComponent },
      { path: 'equity-smart-beta/:id', component: EquityComponent },
      { path: 'fixed-income', component: EquityComponent },
      { path: 'fixed-income/:id', component: EquityComponent },
      { path: 'multi-asset', component: EquityComponent },
      { path: 'multi-asset/:id', component: EquityComponent },
      { path: 'denied', component: AccessDeniedComponent },
      { path: 'page-not-found', component: NotFoundComponent }
    ]
  },
  // { path: 'error', component: ErrorDisplayComponent },
  { path: '**', redirectTo: 'page-not-found' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
