import { Component, Injector, OnInit } from '@angular/core';
import { OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc';
import { environment } from "../environments/environment";
import { OperatorService } from "../services/util/operator.service";

import { FrameworkConfigService } from './../fw/services/framework-config.service';
import { IFrameworkConfigSettings } from './../fw/models/IFrameworkConfigSettings';
import { MenuService } from '../fw/services/menu.service';
import { initialMenuItems } from './app.menu';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  loading : boolean =true;
  ngOnInit(): void { 
    this.loadScript("assets/scripts/custom-scripts.js"); 
   
    var current_location = location.pathname
    var check_routes = false;

    if (!sessionStorage.id_token) {
      this.authorizeUser();
    }
    else {
      this.operator.login.emit(true);
      this.operator.initialized = true;
    }


    var time = this.oauthService.getAccessTokenExpiration();
    
    this.loading = false;
  }
  title = 'app';

  constructor(private oauthService: OAuthService, private operator: OperatorService, private frameworkConfigService: FrameworkConfigService, private menuService: MenuService) {
    
    let config: IFrameworkConfigSettings = {
      socialIcons: [
        { imageFile: 'assets/social-fb-bw.png', alt: 'Facebook', link: 'http://www.facebook.com' },
        { imageFile: 'assets/social-google-bw.png', alt: 'Google', link: 'http://www.google.com' },
        { imageFile: 'assets/social-twitter-bw.png', alt: 'Twitter', link: 'http://www.twitter.com' }
      ],
      showLanguageSelector: false,
      showStatusBar: true,
      showUserControls: true,
      showStatusBarBreakpoint: 800
    }
    frameworkConfigService.configure(config);
    menuService.items = initialMenuItems;
  }

  /**
   * This method makes two calls
   * one get the links for the token and end points and then log you in 
   */
  authorizeUser() {
    // this.oauthService.setupAutomaticSilentRefresh();
    this.oauthService.redirectUri = environment.forgerock_config.redirect_uri;
    this.oauthService.clientId = environment.forgerock_config.client_id;
    this.oauthService.scope = environment.forgerock_config.scope;
    this.oauthService.issuer = environment.forgerock_config.issuer;
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.requireHttps = false;

    // this.oauthService.restartSessionChecksIfStillLoggedIn
    this.oauthService.strictDiscoveryDocumentValidation = false;

    /**
     * This will make two calls
     * 1) ../.well-known/openid-configuration.. e.g., http://authamqa.ofi.com/openam/oauth2/ofipublic/.well-known/openid-configuration
     * 2) take the token_endpoint from call 1 response and to get a token(Log you in)
     */
    this.oauthService.loadDiscoveryDocumentAndLogin().then(() => {
      // console.log(this.oauthService.getAccessToken());
      // console.log(this.oauthService.getIdentityClaims());
      if (this.oauthService.getAccessToken())
        this.operator.login.emit(true);
    });

  }

  // isTokenValid(): boolean {
    
  // }

  public loadScript(url) {
    //console.log('preparing to load...')
    let node = document.createElement('script');
    node.src = url;
    node.type = 'text/javascript';
    document.getElementsByTagName('head')[0].appendChild(node);
  }

} 