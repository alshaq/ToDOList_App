import { IMenuItem } from './../fw/services/menu.service';

export let initialMenuItems: Array<IMenuItem> = [

    {
        text: 'Alternative',
        icon: 'assets/images/links-images/a-link.png',
        route: '/alternative',
        submenu:  [
            {
                text: "Domestic",
                icon: "",
                route: '/equity/domestic',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Energing Market",
                icon: "",
                route: '/equity/energing-market',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "ESG",
                icon: "",
                route: '/equity/ESG',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Global",
                icon: "",
                route:'/equity/global',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "International",
                icon: "",
                route: '/equity/international',
                submenu: null,
                submenuIcon: ""
            },
        ],
        submenuIcon: ""
    },
    {
        text: 'Equity',
        icon: 'assets/images/links-images/e-link.png',
        route: '/equity',
        submenu: [
            {
                text: "Domestic",
                icon: "",
                route: '/equity/domestic',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Energing Market",
                icon: "",
                route: '/equity/energing-market',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "ESG",
                icon: "",
                route: '/equity/ESG',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Global",
                icon: "",
                route:'/equity/global',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "International",
                icon: "",
                route: '/equity/international',
                submenu: null,
                submenuIcon: ""
            },
        ],
        submenuIcon: ""
    },
    {
        text: 'Equity Smart Beta',
        icon: 'assets/images/links-images/equity.png',
        route: '/equity-smart-beta',
        submenu:  [
            {
                text: "Domestic",
                icon: "",
                route: '/equity/domestic',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Energing Market",
                icon: "",
                route: '/equity/energing-market',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "ESG",
                icon: "",
                route: '/equity/ESG',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Global",
                icon: "",
                route:'/equity/global',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "International",
                icon: "",
                route: '/equity/international',
                submenu: null,
                submenuIcon: ""
            },
        ],
        submenuIcon: ""
    },
    {
        text: 'Fixed Income',
        icon: 'assets/images/links-images/lock.png',
        route: '/fixed-income',
        submenu:  [
            {
                text: "Domestic",
                icon: "",
                route: '/equity/domestic',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Energing Market",
                icon: "",
                route: '/equity/energing-market',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "ESG",
                icon: "",
                route: '/equity/ESG',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Global",
                icon: "",
                route:'/equity/global',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "International",
                icon: "",
                route: '/equity/international',
                submenu: null,
                submenuIcon: ""
            },
        ],
        submenuIcon: ""
    },
    {
        text: 'Multi Asset',
        icon: 'assets/images/links-images/multichannel.png',
        route: '/multi-asset',
        submenu:  [
            {
                text: "Domestic",
                icon: "",
                route: '/equity/domestic',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Energing Market",
                icon: "",
                route: '/equity/energing-market',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "ESG",
                icon: "",
                route: '/equity/ESG',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "Global",
                icon: "",
                route:'/equity/global',
                submenu: null,
                submenuIcon: ""
            },
            {
                text: "International", 
                icon: "",
                route: '/equity/international',
                submenu: null,
                submenuIcon: ""
            },
        ],
        submenuIcon: ""
    }

];