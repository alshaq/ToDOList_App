//for responsiveness and menu
var menuResizelimit = 1000;
var verticalMenuclosed = false;
$(function () {
    checkWindowSize()
    adjustRightContent();
  
    $(window).resize(function () {
        
        adjustRightContent();
        if ($(window).width() <= menuResizelimit) {

            verticalMenuclosed = true;
        } else {
            verticalMenuclosed = false;
        }
    })
});


function checkWindowSize() {
    if ($(window).width() <= menuResizelimit) {
       
    }
}

var toggleMenu = false;
// $('#vertical-menu-button').click(function () {
//     //console.log('toggle menu');
//     if (!toggleMenu) {
//         $('.mat-container').addClass("minimized-nav");
//         toggleMenu = true;
//     } else {
//         //   console.log('open menu');
//         $('.mat-container').removeClass("minimized-nav");

//         toggleMenu = false;
//     }
//     adjustRightContent();
// });

$('#vertical-menu-button').click(function () {
    //console.log('toggle menu');
    if (!toggleMenu) {
      
        toggleMenu = true;
    } else {
        
        toggleMenu = false;
    }
    adjustRightContent();
});
//menu
var subIcon = $('li fw-menu-item .menu-item')
$('li fw-menu-item .menu-item').click(function(){
    // console.log(this.subIcon);
    // console.log($('li fw-menu-item .menu-item'));
})
//secondary adjustments to the right content base on the screen resize  
var minimizedMenuWidth = 76;
var maximizedMenuWidth = 274;
var topNavHeight = $('.title-bar').height();
function adjustRightContent() {

    var newWidth = 0;
    var newHeight = 0;
    var windowWidth = $(window).width();
    var windowHeight = $(window).height();

    // newHeight = windowHeight - topNavHeight;

    if (toggleMenu) {
        newWidth = windowWidth - minimizedMenuWidth;


    } else {
        newWidth = windowWidth - maximizedMenuWidth;

    }

    newHeight = windowHeight - topNavHeight;
    $(".title-bar ").css("width", newWidth);
    $("fw-content").css("width", newWidth);
    $(".body-content").css("min-height", newHeight);
    $(".autocomplete-search.mat-autocomplete-panel").css("max-width", $(" .search-group").width())

}




