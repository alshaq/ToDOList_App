import { Injectable } from "@angular/core";
import { HttpClient, HttpRequest, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import { isNullOrUndefined } from "util";
import { ServiceErrorComponent } from "../../../app/modules/error/service-error/service-error.component";
import { OfiHttp } from "../../../app/models/OfiHttp";
import { MethodType } from "../../../app/models/methodTypeConst";

@Injectable()
export class HttpBaseService  {

    
    constructor(protected _httpClient?: HttpClient, protected serviceHandler?: ServiceErrorComponent  ) { 
        
    }

    public get(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<any> {

        return this._request(MethodType.GET, ofiHttp, header);
    }

    public post(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<Response> {
        return this._request(MethodType.POST, ofiHttp, header);
    }

    public put(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<Response> {
        return this._request(MethodType.PUT, ofiHttp, header);
    }

    public delete(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<Response> {
        return this._request(MethodType.DELETE, ofiHttp, header);
    }

    public patch(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<Response> {
        return this._request(MethodType.PATCH, ofiHttp, header);
    }

    public head(ofiHttp: OfiHttp, header?: HttpHeaders): Observable<Response> {
        return this._request(MethodType.HEAD, ofiHttp, header);
    }


    private _request(methodType: string, ofiHttp: OfiHttp, header?: HttpHeaders): Observable<any> {

        var result = this._httpClient.request(methodType, ofiHttp.url, {
            body: ofiHttp.body,
            params: ofiHttp.params,
            headers: header,
        });
        result.subscribe(x =>{

        },(err)=>{
            this.serviceHandler.serviceErrors(err);
        });

        return result;
    }
}

